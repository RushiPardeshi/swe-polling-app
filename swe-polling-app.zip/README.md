# swe-polling-app

This is a polling app for voting.
[![Build Status](https://app.travis-ci.com/RushiPardeshi/swe-polling-app.svg?token=tiSQj8yeThy646YBjc37&branch=main)](https://app.travis-ci.com/RushiPardeshi/swe-polling-app)
[![Coverage Status](https://coveralls.io/repos/github/RushiPardeshi/swe-polling-app/badge.svg?branch=main)](https://coveralls.io/github/RushiPardeshi/swe-polling-app?branch=main)